SERP engine - results, 29 September 2026

All searches were run from one home connection in Lahore, Pakistan, with no proxy,
for Google in US English (hl=en, gl=us), desktop results.

proof-eczema-search
proof-cholesterol-search
  One live search each ("eczema", "how to lower cholesterol"):
  - api-response.json: the API response (resolved URLs, full AI Overview
    with its sources)
  - google-page-screenshot.png: the same Google page
  - google-page.html: that page's HTML, captured after the AI Overview was
    expanded for the screenshot
  - summary.md: the result in readable form, with the test conditions

test-29-searches-hybrid-vs-browser
  15 queries, each run in two modes (30 planned, 29 ran).
  - report.md: conditions, what the two modes mean, summary, notes on the
    results and every search
  - all-api-responses.jsonl: every raw response, one per line
